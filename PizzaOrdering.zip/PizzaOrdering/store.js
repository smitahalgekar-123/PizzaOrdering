import { createStore } from 'redux';
import rootReducer from './src/shared/redux/rootReducer';


export default store = createStore(rootReducer)
